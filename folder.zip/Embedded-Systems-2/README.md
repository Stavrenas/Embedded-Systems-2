# Embedded-Systems-2

## Code usage
Type "make" to compile and then "./main" to run. 
Change QUANTUM in utilities.h to speedup (QUANTUM = 0.01 means 0.01 real sec equals to 1 sec in the simulation)
